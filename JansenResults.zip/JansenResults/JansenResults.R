#Test scripts
library(readxl)
path<-"c:/Users/Nicky/Desktop/Results.xls"
mydata<-read_excel(path, sheet = 1, col_names = TRUE, col_types = NULL, na = "", skip = 0)

summary(mydata)

mean(mydata$x)

mean(mydata$`Term 1`)
rowMeans(8:9, mydata)

plot(mydata$`Term 1`)
plot(mydata$`Term 2`)
plot(mydata$`Term 3`)
plot(mydata$`Term 4`)
plot(mydata$`Term 5`)

hist(mydata$`Term 5`)
boxplot(mydata$`Term 3`)

library(reshape2)
Marks<-melt(mydata)
colnames(Marks)<-c("Term 1", "Term 2", "Term 3", "Term 4", "Term 5")
head(Marks)
library(ggplot2)
ggplot(Marks, aes(x=Marks,y=Percent))+geom_point()
